# Sources and permissions

## Included diagrams

Copyright (c) Microsoft Corporation. The eleven PNG diagrams come from [Azure/AI-Landing-Zones at the reviewed revision](https://github.com/Azure/AI-Landing-Zones/tree/d9ff4b0592622592fd0708bacd9d1cee86c1f529). The images are unchanged. The project distributes its documentation under the [MIT license](https://github.com/Azure/AI-Landing-Zones/blob/d9ff4b0592622592fd0708bacd9d1cee86c1f529/LICENSE). Its [trademark notice](https://github.com/Azure/AI-Landing-Zones/blob/d9ff4b0592622592fd0708bacd9d1cee86c1f529/README.md#L139-L145) applies separately to Microsoft and third-party marks.

Microsoft permits its architecture icons to be copied, distributed and displayed in architecture diagrams, training materials and documentation. This archive reproduces complete diagrams for architectural planning. Anyone reusing the images should consult the specific terms for the icons they use.

- [Azure architecture icons](https://learn.microsoft.com/en-us/azure/architecture/icons/#icon-terms)
- [Microsoft 365 architecture icons](https://learn.microsoft.com/en-us/previous-versions/microsoft-365/solutions/architecture-icons-templates?view=o365-worldwide)
- [Microsoft Power Platform icons](https://learn.microsoft.com/en-us/power-platform/guidance/icons#terms)
- [Microsoft Entra icons](https://learn.microsoft.com/en-us/entra/architecture/architecture-icons)
- [Microsoft Fabric icons](https://learn.microsoft.com/en-us/fabric/fundamentals/icons)
- [Microsoft Trademark and Brand Guidelines](https://www.microsoft.com/en-us/legal/intellectualproperty/trademarks)

Microsoft, Azure, Microsoft 365, Microsoft Copilot, Microsoft Entra, Microsoft Fabric, Microsoft Foundry, Microsoft Power Platform and Microsoft Teams are trademarks of the Microsoft group of companies. Other product names belong to their respective owners. The Container Apps diagram uses the name Ollama to identify a workload. This independent reference package has no affiliation with or endorsement from the upstream projects or trademark owners.

## Sources linked in the index

The Citadel blueprint is copyright (c) Microsoft Corporation and uses the [MIT license](https://github.com/Azure-Samples/foundry-citadel-platform/blob/89d3d70b13aada1972d2e280e00e5aa49a85ad97/LICENSE.md). The AI Hub Gateway accelerator is copyright (c) 2024 Azure Samples and uses the [MIT license](https://github.com/Azure-Samples/ai-hub-gateway-solution-accelerator/blob/ba0674c562099d252680d17222dc004a63019cfc/LICENSE). The README badges are served by Shields.io. These images are available through the original source links in the index.

The [Agentic AI Foundation](https://aaif.io/projects/model-context-protocol) identifies the Model Context Protocol project and its mark. The [CNCF artwork terms](https://github.com/cncf/artwork/blob/main/LICENSE.md) and [Linux Foundation trademark policy](https://www.linuxfoundation.org/legal/trademark-usage) address project logos such as Dapr. Vendors publish their own policies for marks, including [OpenAI](https://openai.com/brand/), [Hugging Face](https://huggingface.co/brand) and [Google](https://about.google/brand-resource-center/products-and-services/). The source-link choices reflect the permissions verified for this package.

## License copies

The Licenses folder contains the three source repositories’ original license notices. The packaging repository’s MIT license, copyright (c) 2026 Miguel P Z, applies to its original index and packaging text. Rights in the upstream images and embedded marks remain with their respective owners.
