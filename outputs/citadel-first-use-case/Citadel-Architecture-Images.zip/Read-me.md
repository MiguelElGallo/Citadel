# Citadel architecture diagrams

Open `Image-index.csv` to find a diagram by layer or topic. Filter **Availability** to see which images are included. **Pinned source** opens the original diagram or the specific README line that displays a badge.

The archive includes 11 unchanged diagrams from Microsoft’s AI Landing Zones project. They show the shared gateway, agent landing zones, workload deployment, private networking, sign-in and document retrieval. Each is attributed in the index.

The index also links to five original Citadel and accelerator images containing separate project or provider branding and four badges from the Citadel README. For these nine items, the source link opens the original, and the archive filename is blank.

`Notices.md` explains the source licenses and terms for the embedded product icons.
